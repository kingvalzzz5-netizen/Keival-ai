package com.keival.ai

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private var pendingLang = "id-ID"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginListening(pendingLang)
            } else {
                js("onMicState('denied')")
            }
        }
    }

    private fun beginListening(lang: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onMicState('unavailable')")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { js("onMicState('listening')") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { js("onMicState('idle')") }
            override fun onError(error: Int) { js("onMicState('error')") }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                js("onMicResult(${JSONObject.quote(t)},true)")
                js("onMicState('idle')")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                js("onMicResult(${JSONObject.quote(t)},false)")
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(intent)
    }

    inner class Bridge {
        private val prefs = getSharedPreferences("keival", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun getKey(): String = prefs.getString("key", "") ?: ""

        @JavascriptInterface
        fun setKey(key: String) {
            prefs.edit().putString("key", key.trim()).apply()
        }

        @JavascriptInterface
        fun startMic(lang: String) {
            runOnUiThread {
                pendingLang = lang
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                } else {
                    beginListening(lang)
                }
            }
        }

        @JavascriptInterface
        fun stopMic() {
            runOnUiThread { recognizer?.stopListening() }
        }

        @JavascriptInterface
        fun ask(id: Int, messagesJson: String, lang: String) {
            Thread {
                var text = ""
                var err = ""
                try {
                    val key = getKey()
                    if (key.isEmpty()) throw Exception(if (lang == "en") "API key is empty. Tap ⚙ to add it." else "API key belum diisi. Ketuk ikon ⚙ untuk mengisinya.")
                    val system = SYSTEM_PROMPT + if (lang == "en") " Always reply in English." else " Selalu jawab dalam bahasa Indonesia."
                    val body = JSONObject()
                        .put("model", MODEL)
                        .put("max_tokens", 1024)
                        .put("system", system)
                        .put("messages", JSONArray(messagesJson))
                    val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 20000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    conn.setRequestProperty("content-type", "application/json")
                    conn.setRequestProperty("x-api-key", key)
                    conn.setRequestProperty("anthropic-version", "2023-06-01")
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val raw = stream.bufferedReader().use { it.readText() }
                    val json = JSONObject(raw)
                    if (code in 200..299) {
                        val content = json.getJSONArray("content")
                        val sb = StringBuilder()
                        for (i in 0 until content.length()) {
                            val block = content.getJSONObject(i)
                            if (block.optString("type") == "text") sb.append(block.getString("text"))
                        }
                        text = sb.toString()
                    } else {
                        err = json.optJSONObject("error")?.optString("message") ?: "Error $code"
                    }
                } catch (e: Exception) {
                    err = e.message ?: "Network error."
                }
                js("onAnswer($id,${JSONObject.quote(text)},${JSONObject.quote(err)})")
            }.start()
        }
    }

    companion object {
        const val MODEL = "claude-sonnet-5-5"
        const val SYSTEM_PROMPT =
            "Kamu adalah KEIVAL AI, asisten AI yang ramah dan membantu menjawab pertanyaan tentang apa saja. " +
            "Jawab singkat, jelas, dan akurat. Jika tidak yakin, katakan terus terang."
    }
}
